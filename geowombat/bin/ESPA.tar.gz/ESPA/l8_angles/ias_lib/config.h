/* Define this on little endian systems. Comment out on big endian systems */
#define HAVE_LITTLE_ENDIAN 1
