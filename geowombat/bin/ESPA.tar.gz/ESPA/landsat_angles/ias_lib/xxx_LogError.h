#ifndef XXX_LOGERROR_H
#define XXX_LOGERROR_H

int xxx_LogError
(
    char *p_UnitName,    /* I: Unit name */
    int LineNumber,      /* I: Line number */
    char *p_ErrorMessage /* O: Error message */
);

#endif
