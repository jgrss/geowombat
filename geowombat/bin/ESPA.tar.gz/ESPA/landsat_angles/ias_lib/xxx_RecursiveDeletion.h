#ifndef DXX_RECURSIVEDELETION_H
#define DXX_RECURSIVEDELETION_H

int xxx_RecursiveDeletion
(
    char *p_Pathname,    /* I: Path name */
    char *p_ErrorMessage /* O: Error message */
);

#endif

