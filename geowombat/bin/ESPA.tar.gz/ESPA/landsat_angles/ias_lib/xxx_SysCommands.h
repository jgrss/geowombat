#ifndef XXX_SYSCOMMANDS_H
#define XXX_SYSCOMMANDS_H

#define CP_COMMAND "/bin/cp"
#define DF_COMMAND "/bin/df"
#define LS_COMMAND "/bin/ls"
#define PS_COMMAND "/bin/ps"
#define RM_COMMAND "/bin/rm"
#define SSH_COMMAND "/usr/bin/ssh"
#define SCP_COMMAND "/usr/bin/scp"
#define MV_COMMAND "/bin/mv"
#define LN_COMMAND "/bin/ln"
#define HSMSTAGE_COMMAND ""

#endif
