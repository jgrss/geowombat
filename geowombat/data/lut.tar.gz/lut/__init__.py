import os
from pathlib import Path


p = Path(os.path.abspath(os.path.dirname(__file__)))

l8_base = p / 'LANDSAT_OLI'
l8_lut = l8_base / 'Continental' / 'view_zenith_0'
l8_zip = p / 'LANDSAT_OLI.zip'
