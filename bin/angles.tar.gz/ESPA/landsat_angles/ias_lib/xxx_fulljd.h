#ifndef XXX_FULLJD_H
#define XXX_FULLJD_H

double xxx_fulljd
(
    int  yr,         /* I: year */
    int  mo,         /* I: month */
    int  day,        /* I: day */
    double seconds   /* I: seconds of day */
);

#endif
