#ifndef LOCAL_DEFINES_H
#define LOCAL_DEFINES_H

#include "ias_satellite_attributes.h"

IAS_SATELLITE_ATTRIBUTES *ias_sat_attr_initialize_landsat8();

#endif
