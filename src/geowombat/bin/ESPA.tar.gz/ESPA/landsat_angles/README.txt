Landsat Angles README.txt 
------------------------------------------------------------------------------
Building the code:
    1. In the root landsat_angles directory run the command:
        make

    2. The executable should now be present in the root directory.

    3. Test the executable by running the following:
        ./landsat_angles

       The output should be as follows:

       Usage: landsat_angles <angle_coefficient_file> <optional parameters>

       Optional parameters:
               -s <subsample factor>
               -b <scan buffer factor>
