#ifndef XXX_STRING_UTILS
#define XXX_STRING_UTILS

char *xxx_strtoupper
(
    char *string_ptr  /* I/O: pointer to string to convert */
);

char *xxx_strtolower
(
    char *string_ptr  /* I/O: pointer to string to convert */
);

#endif
